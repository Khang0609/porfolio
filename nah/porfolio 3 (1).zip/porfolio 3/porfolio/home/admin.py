from django.contrib import admin
from .models import Infor
# Register your models here.
admin.site.register(Infor)