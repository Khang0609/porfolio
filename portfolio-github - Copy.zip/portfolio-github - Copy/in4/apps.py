from django.apps import AppConfig


class In4Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'in4'
